import { Controller } from '@nestjs/common';

@Controller('group-role')
export class GroupRoleController {}
