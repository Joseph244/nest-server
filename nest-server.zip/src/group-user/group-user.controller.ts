import { Controller } from '@nestjs/common';

@Controller('group-user')
export class GroupUserController {}
